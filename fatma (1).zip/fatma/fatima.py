prenom = "fatima"
age = 18
taille = 1.70

print(prenom)
print(age)
print(taille)

if taille <1.60:
    print("tu es petite")

elif taille < 1.90 :
    print("tu as une taille moyenne ")

else:
    print( "tu nest pas petite")  

for i in range (age):
    print(i) 
    
print("111111111111111111111111111111111111111111111111111111111111111")
def multiplie3nombre(a,b,c):
    result = a*b*c
    print (result) 


multiplie3nombre(1,2,3)